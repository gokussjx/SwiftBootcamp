//
//  NoteViewController.swift
//  Notes
//
//  Created by Shawn Moore on 3/1/17.
//  Copyright © 2017 Shawn Moore. All rights reserved.
//

import UIKit

class NoteViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextViewDelegate, UITextFieldDelegate {
    //MARK: - Properties
    @IBOutlet weak var tableView: UITableView!
    
    var note: Note?
    
    weak var delegate: NotesDelegate?
    
    var dateFormatter = DateFormatter()
    
    var titleCellIsExpanded: Bool = false
    var dateCellIsExpanded: Bool = false
    
    var data: [String: Any] = [:]
    
    var responder: UIResponder?
    
    // MARK: - View Controller Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.estimatedRowHeight = 44
        tableView.rowHeight = UITableViewAutomaticDimension

        dateFormatter.dateStyle = .short
        dateFormatter.timeStyle = .short
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Miscellaneous Functions
    @IBAction func saveNote(_ sender: UIBarButtonItem) {
        gatherData()
        
        let title = gatherTitle()
        let content = gatherContent()
        let date = gatherDate()
        
        let note = Note(title: title, content: content, date: date)
        
        delegate?.add(note: note)
        
        self.navigationController?.popViewController(animated: true)
    }
    
    func gatherData() {
        if titleCellIsExpanded {
            gatherTitle()
        } else if dateCellIsExpanded {
            gatherDate()
        }
    }
    
    @discardableResult func gatherTitle() -> String {
        guard titleCellIsExpanded else {
            return data["Title"] as? String ?? ""
        }
        
        let textfieldCell = tableView.cellForRow(at: IndexPath(row: 1, section: 0)) as? TextFieldTableViewCell
        let title = textfieldCell?.textField?.text ?? ""
        data["Title"] = title
        return title
    }
    
    @discardableResult func gatherDate() -> Date {
        guard dateCellIsExpanded else {
            return data["Date"] as? Date ?? Date()
        }
        
        let datepickerCell = tableView.cellForRow(at: IndexPath(row: 2, section: 0)) as? DatePickerTableViewCell
        let date = datepickerCell?.datePicker?.date ?? Date()
        data["Date"] = date
        return date
    }
    
    @discardableResult func gatherContent() -> String {
        let indexPath: IndexPath
        
        if titleCellIsExpanded || dateCellIsExpanded {
            indexPath = IndexPath(row: 3, section: 0)
        } else {
            indexPath = IndexPath(row: 2, section: 0)
        }
        
        let textviewCell = tableView.cellForRow(at: indexPath) as? TextViewTableViewCell
        
        return textviewCell?.textView.text ?? ""
        
    }
    
    // MARK: - UITableViewDelegate and UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleCellIsExpanded || dateCellIsExpanded ? 4 : 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if titleCellIsExpanded {
            switch indexPath.row {
            case 0:
                let cell = tableView.dequeueReusableCell(withIdentifier: "presentationCell", for: indexPath)
                
                cell.textLabel?.text = "Title"
                cell.detailTextLabel?.text = note?.title ?? data["Title"] as? String ?? ""
                
                return cell
            case 1:
                let cell = tableView.dequeueReusableCell(withIdentifier: "textfieldCell", for: indexPath)
                
                if let cell = cell as? TextFieldTableViewCell {
                    cell.textField.text = note?.title ?? data["Title"] as? String
                    cell.textField.becomeFirstResponder()
                    cell.textField.delegate = self
                }
                
                return cell
            case 2:
                let cell = tableView.dequeueReusableCell(withIdentifier: "presentationCell", for: indexPath)
                
                cell.textLabel?.text = "Date"
                
                if let date = note?.date ?? data["Date"] as? Date {
                    cell.detailTextLabel?.text = dateFormatter.string(from: date)
                } else {
                    cell.detailTextLabel?.text = ""
                }
                
                return cell
            case 3:
                let cell = tableView.dequeueReusableCell(withIdentifier: "textviewCell", for: indexPath)
                
                if let cell = cell as? TextViewTableViewCell {
                    cell.textView.text = note?.content ?? ""
                    cell.textView.delegate = self
                }
                
                return cell
            default:
                return UITableViewCell()
            }
        } else if dateCellIsExpanded {
            switch indexPath.row {
            case 0:
                let cell = tableView.dequeueReusableCell(withIdentifier: "presentationCell", for: indexPath)
                
                cell.textLabel?.text = "Title"
                cell.detailTextLabel?.text = note?.title ?? data["Title"] as? String ?? ""
                
                return cell
            case 1:
                let cell = tableView.dequeueReusableCell(withIdentifier: "presentationCell", for: indexPath)
                
                cell.textLabel?.text = "Date"
                
                if let date = note?.date ?? data["Date"] as? Date {
                    cell.detailTextLabel?.text = dateFormatter.string(from: date)
                } else {
                    cell.detailTextLabel?.text = ""
                }
                
                return cell
            case 2:
                let cell = tableView.dequeueReusableCell(withIdentifier: "datepickerCell", for: indexPath)
                
                if let cell = cell as? DatePickerTableViewCell, let date = note?.date ?? data["Date"] as? Date {
                    cell.datePicker.date = date
                }
                
                return cell
            case 3:
                let cell = tableView.dequeueReusableCell(withIdentifier: "textviewCell", for: indexPath)
                
                if let cell = cell as? TextViewTableViewCell {
                    cell.textView.text = note?.content ?? ""
                    cell.textView.delegate = self
                }
                
                return cell
            default:
                return UITableViewCell()
            }
        } else {
            switch indexPath.row {
            case 0:
                let cell = tableView.dequeueReusableCell(withIdentifier: "presentationCell", for: indexPath)
                
                cell.textLabel?.text = "Title"
                cell.detailTextLabel?.text = note?.title ?? data["Title"] as? String ?? ""
                
                return cell
            case 1:
                let cell = tableView.dequeueReusableCell(withIdentifier: "presentationCell", for: indexPath)
                
                cell.textLabel?.text = "Date"
                
                if let date = note?.date ?? data["Date"] as? Date {
                    cell.detailTextLabel?.text = dateFormatter.string(from: date)
                } else {
                    cell.detailTextLabel?.text = ""
                }
                
                return cell
            case 2:
                let cell = tableView.dequeueReusableCell(withIdentifier: "textviewCell", for: indexPath)
                
                if let cell = cell as? TextViewTableViewCell {
                    cell.textView.text = note?.content ?? ""
                    cell.textView.delegate = self
                }
                
                return cell
            default:
                return UITableViewCell()
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        responder?.resignFirstResponder()
        responder = nil
        
        let textFieldIndexPath = IndexPath(row: 1, section: 0)
        let datePickerIndexPath = IndexPath(row: 2, section: 0)
        
        gatherData()
        
        switch indexPath.row {
        case 0:
            if titleCellIsExpanded {
                titleCellIsExpanded = false
                
                tableView.beginUpdates()
                tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .fade)
                tableView.deleteRows(at: [textFieldIndexPath], with: .automatic)
                tableView.endUpdates()
            } else if dateCellIsExpanded {
                dateCellIsExpanded = false
                titleCellIsExpanded = true
                
                tableView.beginUpdates()
                tableView.reloadRows(at: [IndexPath(row: 1, section: 0)], with: .fade)
                tableView.deleteRows(at: [datePickerIndexPath], with: .automatic)
                tableView.insertRows(at: [textFieldIndexPath], with: .automatic)
                tableView.endUpdates()
            } else {
                titleCellIsExpanded = true
                
                tableView.beginUpdates()
                tableView.insertRows(at: [textFieldIndexPath], with: .automatic)
                tableView.endUpdates()
            }
        case 1:
            if titleCellIsExpanded {
                titleCellIsExpanded = false
                
                tableView.beginUpdates()
                tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .fade)
                tableView.deleteRows(at: [textFieldIndexPath], with: .automatic)
                tableView.endUpdates()
            } else if dateCellIsExpanded {
                dateCellIsExpanded = false
                
                tableView.beginUpdates()
                tableView.reloadRows(at: [IndexPath(row: 1, section: 0)], with: .fade)
                tableView.deleteRows(at: [datePickerIndexPath], with: .automatic)
                tableView.endUpdates()
            } else {
                dateCellIsExpanded = true
                
                tableView.beginUpdates()
                tableView.insertRows(at: [datePickerIndexPath], with: .automatic)
                tableView.endUpdates()
            }
        case 2:
            if titleCellIsExpanded {
                titleCellIsExpanded = false
                dateCellIsExpanded = true
                
                tableView.beginUpdates()
                tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .fade)
                tableView.deleteRows(at: [textFieldIndexPath], with: .automatic)
                tableView.insertRows(at: [datePickerIndexPath], with: .automatic)
                tableView.endUpdates()
            } else if dateCellIsExpanded {
                dateCellIsExpanded = false
                
                tableView.beginUpdates()
                tableView.reloadRows(at: [IndexPath(row: 1, section: 0)], with: .fade)
                tableView.deleteRows(at: [datePickerIndexPath], with: .automatic)
                tableView.endUpdates()
            }
        case 3:
            if titleCellIsExpanded {
                titleCellIsExpanded = false
                
                tableView.beginUpdates()
                tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .fade)
                tableView.deleteRows(at: [textFieldIndexPath], with: .automatic)
                tableView.endUpdates()
            } else if dateCellIsExpanded {
                dateCellIsExpanded = false
                
                tableView.beginUpdates()
                tableView.reloadRows(at: [IndexPath(row: 1, section: 0)], with: .fade)
                tableView.deleteRows(at: [datePickerIndexPath], with: .automatic)
                tableView.endUpdates()
            }
        default:
            break
        }
    }
    
    // MARK: - UITextViewDelegate
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        responder = textView
        
        return true
    }
    
    func textViewDidChange(_ textView: UITextView) {
        tableView.beginUpdates()
        tableView.endUpdates()
    }
    
    // MARK: - UITextFieldDelegate
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        responder = textField
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        responder?.resignFirstResponder()
        responder = nil
        
        data["Title"] = textField.text
        
        titleCellIsExpanded = false
        
        tableView.beginUpdates()
        tableView.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .fade)
        tableView.deleteRows(at: [IndexPath(row: 1, section: 0)], with: .automatic)
        tableView.endUpdates()
        
        return true
    }
}
