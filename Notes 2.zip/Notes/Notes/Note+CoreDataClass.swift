//
//  Note+CoreDataClass.swift
//  Notes
//
//  Created by Bidyut Mukherjee on 3/4/17.
//  Copyright © 2017 Shawn Moore. All rights reserved.
//

import UIKit
import CoreData

@objc(Note)
public class Note: NSManagedObject {

    convenience init?(title: String, content: String, date: Date) {

        // Title empty? Get out
        // Get the NSManagedObjectContext from UIApplication. Ensure UIKit is imported, not Foundation
        // Use the context to get the entityDescription
        guard !title.isEmpty,
        let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext,
        let entityDescription = NSEntityDescription.entity(forEntityName: "Note", in: context)
        else {
            return nil
        }

        self.init(entity: entityDescription, insertInto: context)
        
        self.title = title
        self.content = content
        self.date = date as NSDate
    }
}
