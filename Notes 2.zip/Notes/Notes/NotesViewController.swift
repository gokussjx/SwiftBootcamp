//
//  NotesViewController.swift
//  Notes
//
//  Created by Shawn Moore on 3/1/17.
//  Copyright © 2017 Shawn Moore. All rights reserved.
//

import UIKit
import CoreData

//class Note2 {
//    var title: String
//    var content: String
//    var date: Date
//    
//    init(title: String, content: String, date: Date) {
//        self.title = title
//        self.content = content
//        self.date = date
//    }
//}

protocol NotesDelegate: class {
    func add(note: Note)
}

class NotesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, NotesDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    // TODO: Change type to NSManagedObject Subclass
    var notes: [Note] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        if let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext {
            try? self.notes = context.fetch(Note.fetchRequest())
            
//            if let notes = try? context.fetch(Note.fetchRequest() as NSFetchRequest<Note>) {
//                self.notes = notes
//            }
        }
        
        tableView.delegate = self
        tableView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "noteCell", for: indexPath)
        let note = notes[indexPath.row]
        
        // TODO: Set the title of the cell to the title of the note
        cell.textLabel?.text = note.title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "showNoteSegue", sender: self)
    }
    
    @IBAction func addNewNote(_ sender: Any) {
        performSegue(withIdentifier: "showNoteSegue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "showNoteSegue" else { return }
        
        if let destination = segue.destination as? NoteViewController {
        
            destination.delegate = self
            
            if let selectedRow = tableView.indexPathForSelectedRow {
                tableView.deselectRow(at: selectedRow, animated: true)
                destination.note = notes[selectedRow.row]
            }
        }
    }
    
    // MARK: - NotesDelegate
    func add(note: Note) {
        notes.append(note)
        tableView.reloadData()
    }
}
